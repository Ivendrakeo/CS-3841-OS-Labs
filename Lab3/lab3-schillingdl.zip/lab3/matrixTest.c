#include "matrix.h"
#include <stdlib.h>
#include <stdio.h>

#include <time.h>

int main(int argc, char* argv[]){
	clock_t start, end;

	matrix* matrixOne = createMatrix(argv[1]);
	matrix* matrixTwo = createMatrix(argv[2]);
	printMatrix(matrixOne);
	printMatrix(matrixTwo);
	start = clock();
	matrix* resultMatrix = multiplyMatrixNoMultiprocessing(matrixOne, matrixTwo);
	end = clock();
	printf("non multiprocessing: %f\n",((double) (end- start))/ CLOCKS_PER_SEC);
	start = clock();
	matrix* resultMatrixMult = multiplyMatrix(matrixOne, matrixTwo);
	end = clock();
	printf("multiprocessing: %f\n",((double) (end- start))/ CLOCKS_PER_SEC);
	printMatrix(resultMatrix);
	printMatrix(resultMatrixMult);
	deleteMatrix(resultMatrix);
	deleteMatrix(matrixTwo);
	deleteMatrix(matrixOne);
}
